# FastLauncher — ultra-light Android launcher for 2GB-RAM devices

A complete Android Studio project (Kotlin, classic Views — no Jetpack Compose) built around one
rule: **every design decision favors low RAM/CPU/battery over visual richness.**

## What's included
- **Home screen**: `ViewPager2` with `offscreenPageLimit = 1` (only ~2 pages ever alive in RAM)
- **App drawer**: `RecyclerView` grid, `DiffUtil`, stable IDs, fixed size, view-cache tuning
- **Icon loading**: single bounded `LruCache` (sized off the device's real `ActivityManager.memoryClass`,
  not a hardcoded number), RGB_565 bitmaps, single background thread, stale-callback guards
- **Gestures**: one shared `GestureDetector` for the whole home screen (swipe up → drawer,
  swipe down → notifications, long-press → customize) instead of per-view detectors
- **Widgets**: thin `AppWidgetHost` wrapper; `startListening()`/`stopListening()` tied to
  activity visibility, not a persistent service
- **Live wallpaper**: Canvas-based (not OpenGL) engine, capped at 30fps, fully paused via
  `onVisibilityChanged` when off-screen — the two things that make most live wallpapers battery-heavy
- **Icon customization / icon packs**: `IconCache.decode()` is the single seam to swap in
  icon-pack resolution (see "Extending" below)
- **No persistent Service, no WorkManager, no polling loop anywhere** — the only thing that wakes
  the process when idle is the manifest-registered package-change `BroadcastReceiver`

## Why these specific choices (quick reference)

| Concern | Choice | Why |
|---|---|---|
| UI toolkit | Classic Views, not Compose | Compose's runtime + recomposition tracking costs real RAM/CPU at rest; not worth it here |
| Icon bitmap format | `RGB_565` | Half the memory of `ARGB_8888`; flat launcher icons don't need alpha precision |
| Icon cache size | `% of ActivityManager.memoryClass` | Scales correctly across real 2GB devices instead of one guessed constant |
| Icon decoding | 1 background thread, not a pool | Bounded CPU/RAM cost; avoids thread-creation churn |
| Home paging | `ViewPager2`, `offscreenPageLimit=1` | Caps live pages regardless of how many the user configures |
| List updates | `DiffUtil` | Rebinds only changed rows instead of `notifyDataSetChanged()` |
| Gestures | One detector, dispatched by direction | Avoids N velocity trackers running per screen |
| Wallpaper renderer | `Canvas`, 30fps cap, full pause when hidden | The #1 and #2 causes of live-wallpaper battery drain avoided outright |
| `largeHeap` | `false` | Forces disciplined allocation instead of relying on a bigger heap |
| Memory pressure | `onTrimMemory()` shrinks/evicts cache | Lets Android resume us instead of killing us outright |

## Build & run
1. Open the `FastLauncher/` folder in Android Studio (Koala+ recommended).
2. Let it sync — the project uses the plain Gradle/Kotlin DSL with no exotic plugins, so a
   default Android Studio install has everything it needs (this environment has no network
   access, so the Gradle wrapper jar itself isn't bundled here — Android Studio will offer to
   regenerate it, or run `gradle wrapper` once you have Gradle available).
3. Run on a device/emulator. To actually test it as your launcher, after installing:
   `Settings → Apps → Default apps → Home app → FastLauncher`.
4. To profile RAM on a real 2GB device: Android Studio → Profiler → Memory, watch for GC pauses
   >16ms while swiping the drawer/home pages — that's the smoothness budget for 60fps.

## Extending
- **Icon packs**: implement icon-pack resource resolution (reading the pack's `appfilter.xml`)
  inside `IconCache.decode()` — everything downstream (caching, async load, recycling) already works.
- **More home pages**: change `pageCount` in `MainActivity`; RAM stays bounded because of
  `offscreenPageLimit`.
- **Widget picker UI**: `WidgetPickActivity` already returns a bound `widgetId`; wire its result
  into a `HomePageFragment` adapter that calls `WidgetHostManager.createHostView()`.
- **App shortcuts / long-press menu**: `AppDrawerActivity.showAppOptions()` and
  `MainActivity.showHomeCustomizeMenu()` are marked as extension points.

## Testing checklist for "smooth at 90Hz on 2GB RAM"
- [ ] `adb shell dumpsys meminfo com.fastlauncher.app` idle on home screen — target well under
      the device's per-app limit
- [ ] GPU rendering profile (Developer options → Profile HWUI) shows bars under the 16.6ms line
      while flinging the app drawer
- [ ] Battery Historian / `adb shell dumpsys batterystats` over 1hr idle with live wallpaper on —
      should show single-digit % drain, not double digit
- [ ] Force-stop test: swipe through 20 apps in drawer, background, wait for a `TRIM_MEMORY_COMPLETE`
      (or simulate via `adb shell am send-trim-memory <pid> COMPLETE`), reopen — cache should
      evict and reload cleanly, no crash
