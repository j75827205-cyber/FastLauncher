package com.fastlauncher.app.util

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import com.fastlauncher.app.model.AppInfo
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * Bounded, size-aware icon cache.
 *
 * Design choices for 2GB devices:
 *  - LruCache sized in KB (not item count) so it can't blow the heap regardless of icon density.
 *  - A SINGLE background thread (not a pool) does decoding: icon loading is I/O+CPU bound but
 *    low-priority: one thread means we never spawn more concurrent work than a low-end CPU can
 *    retire, and it fully avoids thread-creation churn (each Thread costs ~1MB of native stack).
 *  - Icons are downsampled to a single fixed size up front so we never keep multiple resolutions
 *    of the same icon in memory.
 */
class IconCache(budgetKb: Int) {

    private val cache = object : LruCache<String, Bitmap>(budgetKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    // Single background thread, not a pool: bounded, predictable CPU/RAM cost.
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "icon-decode").apply {
        priority = Thread.MIN_PRIORITY + 1 // never contend with the UI thread on a weak CPU
    } }
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Standard icon side length in dp-equivalent px, resolved once by callers against density. */
    var iconSizePx: Int = 144
        private set

    fun configureIconSize(px: Int) { iconSizePx = px }

    fun getCached(key: String): Bitmap? = cache.get(key)

    /**
     * Loads (or returns cached) icon and delivers it on the main thread. Callers (RecyclerView
     * ViewHolders) MUST guard against stale callbacks — see AppDrawerAdapter — because the view
     * may have been recycled to a different item by the time decode finishes.
     */
    fun loadAsync(context: Context, app: AppInfo, onReady: (Bitmap) -> Unit) {
        cache.get(app.componentKey)?.let { onReady(it); return }

        try {
            executor.execute {
                val bmp = decode(context, app)
                if (bmp != null) {
                    cache.put(app.componentKey, bmp)
                    mainHandler.post { onReady(bmp) }
                }
            }
        } catch (_: RejectedExecutionException) {
            // Executor shutting down (e.g. process dying) — safe to drop the request.
        }
    }

    private fun decode(context: Context, app: AppInfo): Bitmap? {
        return try {
            val pm = context.packageManager
            val drawable: Drawable = pm.getActivityIcon(app.toComponentName())
            drawableToFixedSizeBitmap(drawable, iconSizePx)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }
    }

    private fun drawableToFixedSizeBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        // RGB_565 halves memory vs ARGB_8888 and is visually indistinguishable for flat app icons
        // rendered at launcher size — a deliberate quality/RAM trade-off for this use case.
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, sizePx, sizePx)
        drawable.draw(canvas)
        return bitmap
    }

    fun trimToHalf() {
        val target = cache.maxSize() / 2
        while (cache.size() > target) {
            // LruCache doesn't expose direct "evict oldest N"; trimToSize() does exactly this.
            cache.trimToSize(cache.size() - (cache.size() / 8).coerceAtLeast(1))
        }
    }

    fun evictAll() = cache.evictAll()

    fun shutdown() = executor.shutdownNow()
}
