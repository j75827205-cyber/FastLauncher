package com.fastlauncher.app.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.sin

/**
 * Deliberately Canvas-based, not OpenGL. A GL live wallpaper keeps a GPU context resident and
 * commonly targets 60fps unconditionally; on a 2GB device that is the single biggest live-
 * wallpaper battery drain. This engine instead:
 *   - caps itself to 30fps (imperceptible for a slow ambient animation, half the CPU wake-ups)
 *   - completely stops its render loop when not visible (isVisible callback) — most GL wallpaper
 *     implementations keep rendering off-screen "just in case", which burns battery for nothing
 *   - uses simple Paint/Canvas primitives, so there is no per-frame allocation (no new Paint(),
 *     no new Path() inside draw()) — allocation-in-a-loop is the classic Android GC-jank cause
 */
class MinimalWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MinimalEngine()

    private inner class MinimalEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var phase = 0f

        // Allocated once, reused every frame — never inside draw().
        private val backgroundPaint = Paint().apply { color = Color.parseColor("#101018") }
        private val accentPaint = Paint().apply {
            color = Color.parseColor("#33406080")
            isAntiAlias = true
        }

        private val frameIntervalMs = 1000L / 30L // 30fps cap

        private val drawRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, frameIntervalMs)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(drawRunnable)
            if (isVisible) handler.post(drawRunnable)
            // When not visible (screen off, another wallpaper-hosting app in foreground), we do
            // zero work — no timer, no draw calls, no wakeups.
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(drawRunnable)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val w = canvas.width.toFloat()
                val h = canvas.height.toFloat()

                canvas.drawRect(0f, 0f, w, h, backgroundPaint)

                // One slow-moving soft band — cheap to compute, visually calm, no bitmap decode.
                phase += 0.01f
                val y = h * 0.5f + (h * 0.15f) * sin(phase.toDouble()).toFloat()
                canvas.drawCircle(w * 0.5f, y, w * 0.35f, accentPaint)
            } finally {
                canvas?.let { holder.unlockCanvasAndPost(it) }
            }
        }
    }
}
