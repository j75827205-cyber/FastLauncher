package com.fastlauncher.app.widget

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context

/**
 * Widgets on Android are inherently a shared cost: each hosted widget runs (mostly) inside its
 * own provider's process via RemoteViews, so our launcher's own RAM footprint per widget is just
 * the lightweight AppWidgetHostView shell, not the widget's internal logic. The main thing we
 * control is host lifecycle:
 *  - startListening() only while a home page with widgets is actually visible
 *  - stopListening() in onStop() so we don't keep receiving RemoteViews updates while backgrounded
 */
class WidgetHostManager(context: Context, hostId: Int = 1024) {

    private val appContext = context.applicationContext
    private val widgetManager = AppWidgetManager.getInstance(appContext)
    private val host = AppWidgetHost(appContext, hostId)

    fun startListening() = host.startListening()
    fun stopListening() = host.stopListening()

    fun allocateWidgetId(): Int = host.allocateAppWidgetId()

    fun deleteWidgetId(id: Int) = host.deleteAppWidgetId(id)

    fun createHostView(widgetId: Int, info: AppWidgetProviderInfo): AppWidgetHostView =
        host.createView(appContext, widgetId, info)

    fun getProviderInfo(widgetId: Int): AppWidgetProviderInfo? =
        widgetManager.getAppWidgetInfo(widgetId)

    fun installedProviders(): List<AppWidgetProviderInfo> = widgetManager.installedProviders
}
