package com.fastlauncher.app.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import com.fastlauncher.app.model.AppInfo
import java.util.concurrent.Executors

/**
 * Single source of truth for "what apps are installed". No background Service is used —
 * on Android, a manifest-registered BroadcastReceiver for PACKAGE_ADDED/REMOVED/REPLACED wakes
 * our process only when something actually changes, which costs zero idle RAM/CPU between
 * install events. That's the correct low-power replacement for "poll installed apps".
 */
object AppRepository {

    @Volatile private var cachedApps: List<AppInfo> = emptyList()
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var receiver: BroadcastReceiver? = null

    fun warmUp(context: Context, onLoaded: (List<AppInfo>) -> Unit) {
        if (cachedApps.isNotEmpty()) { onLoaded(cachedApps); return }
        ioExecutor.execute {
            val apps = queryInstalledApps(context)
            cachedApps = apps
            android.os.Handler(android.os.Looper.getMainLooper()).post { onLoaded(apps) }
        }
    }

    fun currentSnapshot(): List<AppInfo> = cachedApps

    private fun queryInstalledApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved.map { ri ->
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                packageName = ri.activityInfo.packageName,
                activityName = ri.activityInfo.name
            )
        }.sortedBy { it.label.lowercase() }
    }

    /** Register once, e.g. from MainActivity.onCreate — cheap, event-driven, no polling. */
    fun registerForChanges(context: Context, onChanged: () -> Unit) {
        if (receiver != null) return
        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                ioExecutor.execute {
                    cachedApps = queryInstalledApps(ctx)
                    android.os.Handler(android.os.Looper.getMainLooper()).post(onChanged)
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        context.applicationContext.registerReceiver(receiver, filter)
    }

    fun unregister(context: Context) {
        receiver?.let { context.applicationContext.unregisterReceiver(it) }
        receiver = null
    }
}
