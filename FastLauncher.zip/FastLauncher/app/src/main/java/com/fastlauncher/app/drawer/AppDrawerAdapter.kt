package com.fastlauncher.app.drawer

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.fastlauncher.app.FastLauncherApp
import com.fastlauncher.app.R
import com.fastlauncher.app.model.AppInfo

class AppDrawerAdapter(
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppDrawerAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    init { setHasStableIds(true) } // lets RecyclerView skip rebinding on pure reorders

    override fun getItemId(position: Int): Long = items[position].componentKey.hashCode().toLong()
    override fun getItemCount() = items.size

    fun submit(newItems: List<AppInfo>) {
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = items.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(o: Int, n: Int) =
                items[o].componentKey == newItems[n].componentKey
            override fun areContentsTheSame(o: Int, n: Int) = items[o] == newItems[n]
        })
        items = newItems
        diff.dispatchUpdatesTo(this) // animates + rebinds only changed rows, not the whole list
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.bind(app, onClick, onLongClick)
    }

    override fun onViewRecycled(holder: VH) {
        holder.boundKey = null // invalidates any in-flight async icon callback for this row
    }

    class VH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        private val icon: ImageView = itemView.findViewById(R.id.appIcon)
        private val label: TextView = itemView.findViewById(R.id.appLabel)
        var boundKey: String? = null

        fun bind(app: AppInfo, onClick: (AppInfo) -> Unit, onLongClick: (AppInfo) -> Unit) {
            boundKey = app.componentKey
            label.text = app.label
            itemView.setOnClickListener { onClick(app) }
            itemView.setOnLongClickListener { onLongClick(app); true }

            val cache = FastLauncherApp.from(itemView.context).iconCache
            val cached = cache.getCached(app.componentKey)
            if (cached != null) {
                icon.setImageBitmap(cached)
            } else {
                icon.setImageResource(R.drawable.ic_app_placeholder) // instant, no flicker to blank
                cache.loadAsync(itemView.context, app) { bmp ->
                    // Guard: only apply if this holder hasn't been recycled to another item since.
                    if (boundKey == app.componentKey) icon.setImageBitmap(bmp)
                }
            }
        }
    }
}
