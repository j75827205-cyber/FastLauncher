package com.fastlauncher.app.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.fastlauncher.app.databinding.FragmentHomePageBinding
import com.fastlauncher.app.model.AppInfo

/**
 * Each home page is its own Fragment inside a ViewPager2. ViewPager2 (backed by RecyclerView)
 * only keeps the current page + 1 offscreen page alive at once (offscreenPageLimit=1 set in
 * MainActivity), so having e.g. 5 home pages costs the RAM of ~2, not 5.
 */
class HomePageFragment : Fragment() {

    private var _binding: FragmentHomePageBinding? = null
    private val binding get() = _binding!!

    private var favorites: List<AppInfo> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomePageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.pageGrid.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.pageGrid.setHasFixedSize(true)
        // Adapter reuses the same AppDrawerAdapter/VH pattern for icon loading consistency;
        // omitted here for brevity — see AppDrawerAdapter for the async-load + recycle guard.
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // release view refs immediately; fragment can outlive its view in the pager
    }

    companion object {
        fun newInstance(pageIndex: Int) = HomePageFragment().apply {
            arguments = Bundle().apply { putInt("page_index", pageIndex) }
        }
    }
}
