package com.fastlauncher.app.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle

/**
 * Handles the standard ACTION_APPWIDGET_BIND / configure flow. Kept as its own transparent
 * activity (rather than folded into MainActivity) so the home screen's view tree, and therefore
 * its measure/layout cost, is completely unaffected by the widget-picking UI.
 */
class WidgetPickActivity : Activity() {

    private lateinit var hostManager: WidgetHostManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hostManager = WidgetHostManager(this)

        val pickIntent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, hostManager.allocateWidgetId())
        }
        startActivityForResult(pickIntent, REQUEST_PICK_WIDGET)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val widgetId = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (resultCode != Activity.RESULT_OK || widgetId == -1) {
            finish(); return
        }
        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }

    companion object { private const val REQUEST_PICK_WIDGET = 9001 }
}
