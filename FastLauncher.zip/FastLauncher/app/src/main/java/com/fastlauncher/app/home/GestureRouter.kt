package com.fastlauncher.app.home

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import kotlin.math.abs

/**
 * One GestureDetector for the whole home screen, not one per widget/icon. Attaching gesture
 * detectors per-view is a common source of touch-latency jank on low-end devices because every
 * detector runs its own velocity tracker; a single router dispatching by direction is both
 * cheaper and simpler to reason about.
 */
class GestureRouter(
    context: Context,
    private val onSwipeUp: () -> Unit,
    private val onSwipeDown: () -> Unit,
    private val onLongPress: (x: Float, y: Float) -> Unit,
    private val onDoubleTap: (() -> Unit)? = null
) {
    private val swipeThresholdPx = (context.resources.displayMetrics.density * 60).toInt()
    private val swipeVelocityThreshold = 300

    val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true // required for subsequent events to be delivered

        override fun onFling(
            e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
        ): Boolean {
            if (e1 == null) return false
            val dy = e2.y - e1.y
            val dx = e2.x - e1.x
            if (abs(dy) > abs(dx) && abs(dy) > swipeThresholdPx && abs(velocityY) > swipeVelocityThreshold) {
                if (dy < 0) onSwipeUp() else onSwipeDown()
                return true
            }
            return false
        }

        override fun onLongPress(e: MotionEvent) = onLongPress(e.x, e.y)

        override fun onDoubleTap(e: MotionEvent): Boolean {
            onDoubleTap?.invoke()
            return onDoubleTap != null
        }
    })

    fun onTouchEvent(event: MotionEvent): Boolean = detector.onTouchEvent(event)
}
