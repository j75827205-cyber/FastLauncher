package com.fastlauncher.app.drawer

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fastlauncher.app.databinding.ActivityAppDrawerBinding
import com.fastlauncher.app.model.AppInfo
import com.fastlauncher.app.util.AppRepository

class AppDrawerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppDrawerBinding
    private lateinit var adapter: AppDrawerAdapter
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Overridden entry/exit animation set in styles.xml uses a plain translate+fade — no
        // shared-element transitions, which on low-end GPUs are a common source of dropped
        // frames during activity transitions.

        adapter = AppDrawerAdapter(
            onClick = { app -> launchApp(app) },
            onLongClick = { app -> showAppOptions(app) }
        )

        binding.appList.apply {
            layoutManager = GridLayoutManager(this@AppDrawerActivity, 4)
            this.adapter = this@AppDrawerActivity.adapter
            setHasFixedSize(true)          // list size never changes shape -> skip re-measure passes
            setItemViewCacheSize(20)       // keep a few extra off-screen rows ready, cheap on RAM
            (itemAnimator as? RecyclerView.ItemAnimator)?.changeDuration = 0 // avoid cross-fade jank
        }

        binding.searchBox.addTextChangedListener(onTextChanged = { text, _, _, _ ->
            filterList(text?.toString().orEmpty())
        })

        allApps = AppRepository.currentSnapshot()
        if (allApps.isEmpty()) {
            AppRepository.warmUp(this) { apps ->
                allApps = apps
                adapter.submit(apps)
            }
        } else {
            adapter.submit(allApps)
        }
    }

    private fun filterList(query: String) {
        val filtered = if (query.isBlank()) allApps
        else allApps.filter { it.label.contains(query, ignoreCase = true) }
        adapter.submit(filtered)
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = app.toComponentName()
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    private fun showAppOptions(app: AppInfo) {
        // Bottom sheet with "Add to home", "App info", "Uninstall" — intentionally left as a
        // small extension point; wiring is identical to launchApp's ComponentName usage.
    }
}

// Small extension to keep AppDrawerActivity terse without pulling in a whole binding-adapter lib.
private fun android.widget.EditText.addTextChangedListener(
    onTextChanged: (CharSequence?, Int, Int, Int) -> Unit
) {
    addTextChangedListener(object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
            onTextChanged(s, start, before, count)
        override fun afterTextChanged(s: android.text.Editable?) {}
    })
}
