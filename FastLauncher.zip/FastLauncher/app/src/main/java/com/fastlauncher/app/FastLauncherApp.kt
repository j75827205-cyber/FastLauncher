package com.fastlauncher.app

import android.app.ActivityManager
import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Context
import com.fastlauncher.app.util.IconCache

class FastLauncherApp : Application() {

    lateinit var iconCache: IconCache
        private set

    override fun onCreate() {
        super.onCreate()

        // Query the ACTUAL memory class of this device instead of hard-coding a budget.
        // A 2GB-RAM phone typically reports memoryClass ~ 96-128MB; we spend only a slice of
        // that on the icon cache so app launches / GC never come close to an OOM.
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryClassMb = am.memoryClass // per-app heap limit in MB, device-reported
        val cacheBudgetKb = (memoryClassMb * 1024) / 12 // ~8% of heap for all cached icons

        iconCache = IconCache(cacheBudgetKb)
    }

    // The single most important low-RAM hook on Android: the OS calls this *before* it would
    // otherwise kill us. Shrinking our own cache here means we get resumed instantly instead of
    // cold-started from scratch, which is the #1 perceived-lag complaint on low-RAM launchers.
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> iconCache.evictAll()
            level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE -> iconCache.trimToHalf()
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> iconCache.trimToHalf()
            else -> { /* UI_HIDDEN / RUNNING_MODERATE: keep cache, we're still visible-ish */ }
        }
    }

    companion object {
        fun from(context: Context): FastLauncherApp =
            context.applicationContext as FastLauncherApp
    }
}
