package com.fastlauncher.app.home

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.fastlauncher.app.databinding.ActivityMainBinding
import com.fastlauncher.app.drawer.AppDrawerActivity
import com.fastlauncher.app.util.AppRepository

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var gestureRouter: GestureRouter

    private val pageCount = 3 // fixed page count for v1; extend by driving this from saved prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Warm the app list on a background thread the moment the launcher starts, so the
        // drawer opens with zero perceived load time on first swipe.
        AppRepository.warmUp(applicationContext) { /* cached; drawer reads snapshot directly */ }
        AppRepository.registerForChanges(applicationContext) { /* drawer re-reads snapshot on open */ }

        binding.homePager.apply {
            adapter = object : FragmentStateAdapter(this@MainActivity as FragmentActivity) {
                override fun getItemCount() = pageCount
                override fun createFragment(position: Int) = HomePageFragment.newInstance(position)
            }
            // Keep only 1 extra page alive off-screen in each direction. This is the single
            // biggest lever against RAM growth from a multi-page home screen.
            offscreenPageLimit = 1
            // Disable the default over-scroll glow + reduce page-transform work: plain slide,
            // no custom PageTransformer (custom transformers redraw every frame during swipe).
            (getChildAt(0) as? androidx.recyclerview.widget.RecyclerView)?.overScrollMode =
                android.view.View.OVER_SCROLL_NEVER
        }

        gestureRouter = GestureRouter(
            context = this,
            onSwipeUp = { openAppDrawer() },
            onSwipeDown = { expandNotificationShade() },
            onLongPress = { x, y -> showHomeCustomizeMenu(x, y) }
        )
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Let ViewPager2 handle horizontal paging first; only intercept for up/down swipes it
        // ignores. Keeping this logic in dispatchTouchEvent (not a custom ViewGroup) avoids an
        // extra view layer in the hierarchy, which matters for measure/layout pass cost.
        gestureRouter.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun openAppDrawer() {
        startActivity(Intent(this, AppDrawerActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    @Suppress("DEPRECATION")
    private fun expandNotificationShade() {
        // No public API for this; common launcher workaround via Instrumentation shell command
        // requires no special permission on most OEM builds but is best-effort and OEM-variable.
        try {
            Runtime.getRuntime().exec("cmd statusbar expand-notifications")
        } catch (_: Exception) { /* silently ignore on OEMs that block it */ }
    }

    private fun showHomeCustomizeMenu(x: Float, y: Float) {
        // Extension point: wallpaper picker / widget picker / icon-pack picker bottom sheet.
        // Widget picker flow: see widget/WidgetHostManager.kt for the AppWidgetHost wiring.
    }

    override fun onDestroy() {
        super.onDestroy()
        AppRepository.unregister(applicationContext)
    }

    override fun onBackPressed() {
        // Intentionally does nothing: a launcher's home screen has no "back" destination,
        // and disabling it avoids the default back animation's extra composited layer.
    }
}
