package com.fastlauncher.app.model

import android.content.ComponentName

/**
 * Deliberately holds no Drawable/Bitmap. Icons are fetched on demand from IconCache and keyed
 * by [componentKey], so a list of 500 installed apps costs only a few hundred bytes here —
 * the icon bitmaps themselves live in one bounded LruCache, not duplicated per list item.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val userSerial: Long = 0L, // supports work-profile apps on multi-user devices
    var isFavorite: Boolean = false
) {
    val componentKey: String get() = "$packageName/$activityName/$userSerial"

    fun toComponentName(): ComponentName = ComponentName(packageName, activityName)
}
