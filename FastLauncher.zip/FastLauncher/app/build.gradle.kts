plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fastlauncher.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fastlauncher.app"
        minSdk = 21          // Android 5.0 — covers virtually all 2GB RAM devices still in use
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        viewBinding = true   // no Compose: Compose's runtime + recomposition overhead is not worth it on 2GB devices
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes.add("META-INF/*")
    }
}

dependencies {
    // Deliberately minimal dependency surface — every library adds APK size, class-load time
    // and (for anything with its own thread pools / caches) idle RAM.
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")   // recycles views: O(1) memory for any list length
    implementation("androidx.viewpager2:viewpager2:1.1.0")       // home-screen paging, hardware-accelerated by default
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}
