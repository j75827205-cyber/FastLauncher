# Aggressive shrinking is fine — we have no reflection-heavy libs, no Compose, no Gson models to keep.
-optimizationpasses 5
-allowaccessmodification
-dontpreverify

# Keep the live wallpaper service name (referenced from XML metadata by string)
-keep class com.fastlauncher.app.wallpaper.MinimalWallpaperService { *; }
